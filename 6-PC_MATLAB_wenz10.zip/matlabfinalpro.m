delete(instrfindall);
s = serial('COM3');
s.baudrate = 9600;
s.terminator = 'CR';
signal = animatedline('Color','k');
fopen(s);
time = 0;
while(1)
    digital = str2num(fgetl(s))
    analog = ((digital * 3.3/1023)-1.71)/0.41;
    angle = real(asin(analog)*180/pi)
    addpoints(signal,time,angle);
    drawnow
    time=time+1;
end
fclose(s)
delete(s)